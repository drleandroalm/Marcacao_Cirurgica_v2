import Foundation
import UIKit

class FormExporter {
    
    static func copyToClipboard(form: SurgicalRequestForm) -> Bool {
        let filledTemplate = generateFilledTemplate(form: form)
        UIPasteboard.general.string = filledTemplate
        return true
    }
    
    static func shareForm(form: SurgicalRequestForm, from viewController: UIViewController) {
        let text = generateFilledTemplate(form: form)
        let activityVC = UIActivityViewController(activityItems: [text], applicationActivities: nil)
        
        if let popoverController = activityVC.popoverPresentationController {
            popoverController.sourceView = viewController.view
            popoverController.sourceRect = CGRect(x: viewController.view.bounds.midX, y: viewController.view.bounds.midY, width: 0, height: 0)
            popoverController.permittedArrowDirections = []
        }
        
        viewController.present(activityVC, animated: true)
    }
    
    static func saveToDocuments(form: SurgicalRequestForm) -> URL? {
        let text = generateFilledTemplate(form: form)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
        let timestamp = dateFormatter.string(from: Date())
        let fileName = "solicitacao_cirurgica_\(timestamp).txt"
        
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return nil
        }
        
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        
        do {
            try text.write(to: fileURL, atomically: true, encoding: .utf8)
            return fileURL
        } catch {
            print("Failed to save file: \(error)")
            return nil
        }
    }
    
    static func generateFilledTemplate(form: SurgicalRequestForm) -> String {
        let fields = form.fields
        
        let template = """
        SOLICITAÇÃO DE AGENDAMENTO CIRÚRGICO
        
        DADOS DO PACIENTE:
        Nome: \(fields[0].value.isEmpty ? fields[0].placeholder : fields[0].value)
        Idade: \(fields[1].value.isEmpty ? fields[1].placeholder : "\(fields[1].value) anos")
        Telefone: \(fields[2].value.isEmpty ? fields[2].placeholder : fields[2].formattedValue())
        Preceptor: \(fields[3].value.isEmpty ? fields[3].placeholder : fields[3].value)
        Paciente em precaução: ( ) Não (  )sim
        Paciente com doença infecto contagiosa: ( X ) Não (  )sim
        DADOS DA CIRURGIA:
        Data: \(fields[4].value.isEmpty ? fields[4].placeholder : fields[4].value)
        Preferência de horário: \(fields[5].value.isEmpty ? fields[5].placeholder : fields[5].value)
        Procedimento: \(fields[6].value.isEmpty ? fields[6].placeholder : fields[6].value)
        Convênio: SUS
        Necessidade de CTI: () Não ()sim
        Reserva de hemocomponentes: (x) Não   () Sim:    Especificar:
        Necessidade de OPME:  (X) Não   ()
        Fornecedor:
        Necessidade de equipamentos específicos:  ( X) Não   ()Sim
        Especificar:
        Tempo do procedimento: \(fields[7].value.isEmpty ? fields[7].placeholder : fields[7].value)
        """
        
        return template
    }
    
    static func exportAsJSON(form: SurgicalRequestForm) -> Data? {
        var jsonDict: [String: Any] = [:]
        
        for field in form.fields {
            jsonDict[field.id] = field.value.isEmpty ? nil : field.value
        }
        
        jsonDict["exportDate"] = ISO8601DateFormatter().string(from: Date())
        jsonDict["formType"] = "SOLICITAÇÃO DE AGENDAMENTO CIRÚRGICO"
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: jsonDict, options: .prettyPrinted)
            return jsonData
        } catch {
            print("Failed to create JSON: \(error)")
            return nil
        }
    }
}