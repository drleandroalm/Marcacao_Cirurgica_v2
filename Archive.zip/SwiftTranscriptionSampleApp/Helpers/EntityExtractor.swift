import Foundation
import FoundationModels

struct ExtractedEntity {
    let fieldId: String
    let value: String
    let confidence: Double
    let alternatives: [String]
    let originalText: String
}

struct ExtractionResult {
    let entities: [ExtractedEntity]
    let unprocessedText: String
    let confidence: Double
}

@Observable
class EntityExtractor {
    private let model: SystemLanguageModel
    private var session: LanguageModelSession?
    
    static let shared = EntityExtractor()
    
    private init() {
        self.model = SystemLanguageModel.default
    }
    
    var isAvailable: Bool {
        return model.isAvailable
    }
    
    func extractEntities(from transcription: String, for form: SurgicalRequestForm) async throws -> ExtractionResult {
        guard isAvailable else {
            throw EntityExtractionError.modelUnavailable
        }
        
        let session = LanguageModelSession(model: model)
        self.session = session
        
        let prompt = buildExtractionPrompt(for: transcription, fields: form.fields)
        
        do {
            let response = try await session.respond(to: prompt)
            let result = try parseExtractionResponse(response.content, originalText: transcription)
            return result
        } catch {
            throw EntityExtractionError.extractionFailed(error)
        }
    }
    
    private func buildExtractionPrompt(for text: String, fields: [TemplateField]) -> String {
        let fieldsDescription = fields.map { field in
            let typeDescription = getFieldTypeDescription(field.fieldType)
            return "- \(field.id): \(field.label) (\(typeDescription))"
        }.joined(separator: "\n")
        
        return """
        Você é um assistente especializado em extrair informações médicas de transcrições em português brasileiro.

        CAMPOS DO FORMULÁRIO:
        \(fieldsDescription)

        REGRAS DE EXTRAÇÃO:
        1. Extraia informações mesmo quando ditas fora de ordem
        2. Todos os nomes próprios devem começar com letra maiúscula
        3. Datas no formato DD/MM/AAAA
        4. Horários no formato HH:MM
        5. Telefones apenas números (10-11 dígitos)
        6. Idades apenas números
        7. Se não encontrar uma informação, retorne "VAZIO"
        8. Indique confiança: ALTA (90-100%), MEDIA (70-89%), BAIXA (0-69%)

        TEXTO DA TRANSCRIÇÃO:
        "\(text)"

        RESPONDA EXATAMENTE NESTE FORMATO JSON:
        {
            "entities": [
                {
                    "fieldId": "patientName",
                    "value": "João Silva",
                    "confidence": 95,
                    "alternatives": ["João da Silva", "João Santos"]
                }
            ],
            "unprocessed": "texto não processado",
            "overallConfidence": 87
        }
        
        Não adicione texto explicativo, apenas o JSON válido.
        """
    }
    
    private func getFieldTypeDescription(_ fieldType: FieldType) -> String {
        switch fieldType {
        case .text:
            return "Nome próprio ou texto livre"
        case .number:
            return "Número (ex: idade)"
        case .date:
            return "Data no formato DD/MM/AAAA"
        case .time:
            return "Horário no formato HH:MM"
        case .phone:
            return "Telefone (10-11 dígitos)"
        }
    }
    
    private func parseExtractionResponse(_ response: String, originalText: String) throws -> ExtractionResult {
        guard let jsonData = response.data(using: .utf8) else {
            throw EntityExtractionError.invalidResponse
        }
        
        do {
            let json = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any]
            
            guard let json = json,
                  let entitiesArray = json["entities"] as? [[String: Any]],
                  let overallConfidence = json["overallConfidence"] as? Double else {
                throw EntityExtractionError.invalidResponse
            }
            
            let entities = try entitiesArray.compactMap { entityDict -> ExtractedEntity? in
                guard let fieldId = entityDict["fieldId"] as? String,
                      let value = entityDict["value"] as? String,
                      let confidence = entityDict["confidence"] as? Double else {
                    return nil
                }
                
                let alternatives = entityDict["alternatives"] as? [String] ?? []
                
                // Skip empty values
                guard value != "VAZIO" && !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    return nil
                }
                
                return ExtractedEntity(
                    fieldId: fieldId,
                    value: capitalizeProperly(value),
                    confidence: confidence / 100.0, // Convert percentage to decimal
                    alternatives: alternatives.map { capitalizeProperly($0) },
                    originalText: originalText
                )
            }
            
            let unprocessed = json["unprocessed"] as? String ?? ""
            
            return ExtractionResult(
                entities: entities,
                unprocessedText: unprocessed,
                confidence: overallConfidence / 100.0
            )
            
        } catch {
            // Fallback: try to extract using basic pattern matching
            return try fallbackExtraction(from: originalText)
        }
    }
    
    private func capitalizeProperly(_ text: String) -> String {
        return text.split(separator: " ")
            .map { word in
                let lowercased = word.lowercased()
                
                // Don't capitalize articles, prepositions, and conjunctions in Portuguese
                let dontCapitalize = ["de", "da", "do", "das", "dos", "e", "em", "na", "no", "nas", "nos", "com", "para", "por", "a", "o", "as", "os"]
                
                if dontCapitalize.contains(lowercased) {
                    return String(lowercased)
                } else {
                    return String(word.prefix(1).uppercased() + word.dropFirst().lowercased())
                }
            }
            .joined(separator: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    private func fallbackExtraction(from text: String) throws -> ExtractionResult {
        // Basic pattern matching as fallback
        var entities: [ExtractedEntity] = []
        
        // Extract phone numbers
        let phonePattern = #"(\d{10,11})"#
        if let phoneMatch = text.range(of: phonePattern, options: .regularExpression) {
            let phone = String(text[phoneMatch])
            entities.append(ExtractedEntity(
                fieldId: "patientPhone",
                value: phone,
                confidence: 0.7,
                alternatives: [],
                originalText: text
            ))
        }
        
        // Extract dates (DD/MM/YYYY pattern)
        let datePattern = #"(\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4})"#
        if let dateMatch = text.range(of: datePattern, options: .regularExpression) {
            let date = String(text[dateMatch])
            entities.append(ExtractedEntity(
                fieldId: "surgeryDate",
                value: date,
                confidence: 0.8,
                alternatives: [],
                originalText: text
            ))
        }
        
        // Extract times (HH:MM pattern)
        let timePattern = #"(\d{1,2}:\d{2})"#
        if let timeMatch = text.range(of: timePattern, options: .regularExpression) {
            let time = String(text[timeMatch])
            entities.append(ExtractedEntity(
                fieldId: "surgeryTime",
                value: time,
                confidence: 0.8,
                alternatives: [],
                originalText: text
            ))
        }
        
        return ExtractionResult(
            entities: entities,
            unprocessedText: text,
            confidence: 0.6
        )
    }
    
    func refineEntity(fieldId: String, originalValue: String, context: String) async throws -> ExtractedEntity? {
        guard isAvailable else { return nil }
        
        let session = LanguageModelSession(model: model)
        
        let prompt = """
        Refine esta informação médica extraída:
        
        Campo: \(fieldId)
        Valor original: \(originalValue)
        Contexto: \(context)
        
        Forneça uma versão melhorada seguindo as regras:
        - Nomes próprios com primeira letra maiúscula
        - Datas no formato DD/MM/AAAA
        - Horários no formato HH:MM
        - Telefones apenas números
        
        Responda apenas com o valor refinado, sem explicações.
        """
        
        do {
            let response = try await session.respond(to: prompt)
            let refinedValue = capitalizeProperly(response.content.trimmingCharacters(in: .whitespacesAndNewlines))
            
            return ExtractedEntity(
                fieldId: fieldId,
                value: refinedValue,
                confidence: 0.9,
                alternatives: [originalValue],
                originalText: context
            )
        } catch {
            return nil
        }
    }
}

enum EntityExtractionError: LocalizedError {
    case modelUnavailable
    case extractionFailed(Error)
    case invalidResponse
    
    var errorDescription: String? {
        switch self {
        case .modelUnavailable:
            return "Foundation Models não está disponível"
        case .extractionFailed(let error):
            return "Falha na extração: \(error.localizedDescription)"
        case .invalidResponse:
            return "Resposta inválida do modelo"
        }
    }
}