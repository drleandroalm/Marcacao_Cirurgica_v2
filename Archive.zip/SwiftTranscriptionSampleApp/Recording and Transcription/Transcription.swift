/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
Live transcription code
*/

import Foundation
import Speech
import SwiftUI
import FoundationModels

@Observable
final class SpokenWordTranscriber: Sendable {
    private var inputSequence: AsyncStream<AnalyzerInput>?
    private var inputBuilder: AsyncStream<AnalyzerInput>.Continuation?
    private var transcriber: SpeechTranscriber?
    private var analyzer: SpeechAnalyzer?
    private var recognizerTask: Task<(), Error>?
    
    static let magenta = Color(red: 0.54, green: 0.02, blue: 0.6).opacity(0.8) // #e81cff
    
    // The format of the audio.
    var analyzerFormat: AVAudioFormat?
    
    var converter = BufferConverter()
    var downloadProgress: Progress?
    
    var form: SurgicalRequestForm
    var onFieldComplete: ((String) -> Void)?
    var onContinuousComplete: ((ExtractionResult) -> Void)?
    
    var volatileTranscript: AttributedString = ""
    var finalizedTranscript: AttributedString = ""
    var continuousTranscript: String = ""
    var isContinuousMode: Bool = false
    
    static let locale = Locale(identifier: "pt-BR")
    
    init(form: SurgicalRequestForm, onFieldComplete: ((String) -> Void)? = nil, onContinuousComplete: ((ExtractionResult) -> Void)? = nil, isContinuousMode: Bool = false) {
        self.form = form
        self.onFieldComplete = onFieldComplete
        self.onContinuousComplete = onContinuousComplete
        self.isContinuousMode = isContinuousMode
    }
    
    func setUpTranscriber() async throws {
        transcriber = SpeechTranscriber(locale: Self.locale,
                                        transcriptionOptions: [],
                                        reportingOptions: [.volatileResults],
                                        attributeOptions: [.audioTimeRange])

        guard let transcriber else {
            throw TranscriptionError.failedToSetupRecognitionStream
        }

        analyzer = SpeechAnalyzer(modules: [transcriber])
        
        do {
            try await ensureModel(transcriber: transcriber, locale: Self.locale)
        } catch let error as TranscriptionError {
            print(error)
            return
        }
        
        self.analyzerFormat = await SpeechAnalyzer.bestAvailableAudioFormat(compatibleWith: [transcriber])
        (inputSequence, inputBuilder) = AsyncStream<AnalyzerInput>.makeStream()
        
        guard let inputSequence else { return }
        
        recognizerTask = Task {
            do {
                for try await case let result in transcriber.results {
                    let text = result.text
                    if result.isFinal {
                        finalizedTranscript += text
                        volatileTranscript = ""
                        
                        if isContinuousMode {
                            continuousTranscript += " " + String(text.characters)
                            await processContinuousTranscription()
                        } else {
                            updateStoryWithNewText(withFinal: text)
                        }
                    } else {
                        // Process volatile text for display
                        var processedText = AttributedString(String(text.characters))
                        if !isContinuousMode, let currentField = form.currentField {
                            let processed = TranscriptionProcessor.processText(String(text.characters), fieldType: currentField.fieldType)
                            processedText = AttributedString(processed)
                        }
                        processedText.foregroundColor = .purple.opacity(0.4)
                        volatileTranscript = processedText
                    }
                }
            } catch {
                print("speech recognition failed")
            }
        }
        
        try await analyzer?.start(inputSequence: inputSequence)
    }
    
    func updateStoryWithNewText(withFinal str: AttributedString) {
        var plainText = String(str.characters)
        
        // Apply processing based on current field type
        if let currentField = form.currentField {
            plainText = TranscriptionProcessor.processText(plainText, fieldType: currentField.fieldType)
        }
        
        form.updateCurrentFieldValue(plainText)
        onFieldComplete?(plainText)
    }
    
    private func processContinuousTranscription() async {
        guard !continuousTranscript.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        
        do {
            let extractor = EntityExtractor.shared
            let result = try await extractor.extractEntities(from: continuousTranscript, for: form)
            
            // Update form with extracted entities
            for entity in result.entities {
                if let fieldIndex = form.fields.firstIndex(where: { $0.id == entity.fieldId }) {
                    form.fields[fieldIndex].value = entity.value
                }
            }
            
            onContinuousComplete?(result)
        } catch {
            print("Failed to extract entities: \(error)")
        }
    }
    
    func finishContinuousTranscription() async {
        await processContinuousTranscription()
    }
    
    func resetContinuousMode() {
        continuousTranscript = ""
        finalizedTranscript = AttributedString("")
        volatileTranscript = AttributedString("")
    }
    
    func streamAudioToTranscriber(_ buffer: AVAudioPCMBuffer) async throws {
        guard let inputBuilder, let analyzerFormat else {
            throw TranscriptionError.invalidAudioDataType
        }
        
        let converted = try self.converter.convertBuffer(buffer, to: analyzerFormat)
        let input = AnalyzerInput(buffer: converted)
        
        inputBuilder.yield(input)
    }
    
    public func finishTranscribing() async throws {
        inputBuilder?.finish()
        try await analyzer?.finalizeAndFinishThroughEndOfInput()
        recognizerTask?.cancel()
        recognizerTask = nil
    }
}

extension SpokenWordTranscriber {
    public func ensureModel(transcriber: SpeechTranscriber, locale: Locale) async throws {
        guard await supported(locale: locale) else {
            throw TranscriptionError.localeNotSupported
        }
        
        if await installed(locale: locale) {
            return
        } else {
            try await downloadIfNeeded(for: transcriber)
        }
    }
    
    func supported(locale: Locale) async -> Bool {
        let supported = await SpeechTranscriber.supportedLocales
        return supported.map { $0.identifier(.bcp47) }.contains(locale.identifier(.bcp47))
    }

    func installed(locale: Locale) async -> Bool {
        let installed = await Set(SpeechTranscriber.installedLocales)
        return installed.map { $0.identifier(.bcp47) }.contains(locale.identifier(.bcp47))
    }

    func downloadIfNeeded(for module: SpeechTranscriber) async throws {
        if let downloader = try await AssetInventory.assetInstallationRequest(supporting: [module]) {
            self.downloadProgress = downloader.progress
            try await downloader.downloadAndInstall()
        }
    }
    
    func deallocate() async {
        // AssetInventory deallocation is handled automatically in iOS 26
        // Manual deallocation is no longer needed
    }
}
