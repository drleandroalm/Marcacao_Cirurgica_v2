import SwiftUI
import Speech

struct FormFillerView: View {
    @State private var form = SurgicalRequestForm()
    @State private var isRecording = false
    @State private var showingExportOptions = false
    @State private var showCopiedAlert = false
    @State private var recorder: Recorder?
    @State private var speechTranscriber: SpokenWordTranscriber?
    @State private var isContinuousMode = false
    @State private var extractionResult: ExtractionResult?
    @State private var showingPreview = false
    
    init() {
        
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                modeToggle
                progressBar
                
                ScrollView {
                    VStack(spacing: 20) {
                        if isContinuousMode {
                            continuousRecordingCard
                        } else {
                            currentFieldCard
                        }
                        fieldsOverview
                    }
                    .padding()
                }
                
                if form.isComplete {
                    completionToolbar
                }
                
                controlToolbar
            }
            .navigationTitle("Formulário Cirúrgico")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Copiado!", isPresented: $showCopiedAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("O formulário foi copiado para a área de transferência")
            }
            .onAppear {
                setupRecorder()
            }
            .sheet(isPresented: $showingPreview) {
                if let result = extractionResult {
                    FormPreviewView(
                        extractionResult: result,
                        form: form,
                        onConfirm: { confirmedForm in
                            form = confirmedForm
                            showingPreview = false
                            extractionResult = nil
                        },
                        onRetry: {
                            showingPreview = false
                            extractionResult = nil
                            form.reset()
                            speechTranscriber?.resetContinuousMode()
                        }
                    )
                }
            }
        }
    }
    
    private var modeToggle: some View {
        HStack {
            Text("Modo:")
                .font(.caption)
                .foregroundColor(.secondary)
            
            Picker("Modo de Gravação", selection: $isContinuousMode) {
                Text("Campo por Campo").tag(false)
                Text("Contínuo").tag(true)
            }
            .pickerStyle(.segmented)
            .disabled(isRecording)
            
            Spacer()
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(Color(.systemGray6))
        .onChange(of: isContinuousMode) { _, newValue in
            if newValue != isContinuousMode {
                setupRecorder()
            }
        }
    }
    
    private var continuousRecordingCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Image(systemName: isRecording ? "waveform" : "mic.slash")
                    .foregroundColor(isRecording ? .red : .gray)
                
                Text("Gravação Contínua")
                    .font(.headline)
                
                Spacer()
                
                if EntityExtractor.shared.isAvailable {
                    Image(systemName: "brain.head.profile")
                        .foregroundColor(.blue)
                }
            }
            
            if isRecording {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Fale todas as informações do paciente...")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    if let transcriber = speechTranscriber {
                        Text(transcriber.volatileTranscript)
                            .foregroundColor(.purple.opacity(0.4))
                            .font(.body)
                        
                        if !transcriber.continuousTranscript.isEmpty {
                            Text("Já Transcrito:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .padding(.top, 8)
                            
                            Text(transcriber.continuousTranscript)
                                .font(.footnote)
                                .foregroundColor(.primary)
                                .padding()
                                .background(Color(.systemGray6))
                                .cornerRadius(8)
                        }
                    }
                }
            } else {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Toque em 'Gravar' e diga todas as informações de uma só vez:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text("Exemplo: 'Paciente João Silva, 45 anos, telefone 11987654321, cirurgia amanhã às 14 horas, procedimento apendicectomia, doutor Pedro Santos.'")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .italic()
                        .padding()
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(8)
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
    }
    
    private var progressBar: some View {
        VStack(spacing: 8) {
            HStack {
                Text("Campo \(form.currentFieldIndex + 1) de \(form.fields.count)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                Text("\(Int(form.progressPercentage * 100))% Completo")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            ProgressView(value: form.progressPercentage)
                .tint(.blue)
        }
        .padding()
        .background(Color(.systemGray6))
    }
    
    private var currentFieldCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Image(systemName: form.currentField?.isComplete == true ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(form.currentField?.isComplete == true ? .green : .gray)
                
                Text(form.currentField?.label ?? "")
                    .font(.headline)
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Valor Transcrito:")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Text(form.currentField?.value.isEmpty == true ? form.currentField?.placeholder ?? "" : form.currentField?.value ?? "")
                    .font(.body)
                    .foregroundColor(form.currentField?.value.isEmpty == true ? .gray : .primary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                
                if isRecording, let transcriber = speechTranscriber {
                    Text(transcriber.volatileTranscript)
                        .foregroundColor(.purple.opacity(0.4))
                        .font(.body)
                }
            }
            
            if let field = form.currentField, !field.value.isEmpty && !field.validate() {
                HStack {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundColor(.orange)
                    Text(validationMessage(for: field))
                        .font(.caption)
                        .foregroundColor(.orange)
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
    }
    
    private var fieldsOverview: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Todos os Campos")
                .font(.headline)
                .padding(.bottom, 8)
            
            ForEach(Array(form.fields.enumerated()), id: \.element.id) { index, field in
                HStack {
                    Image(systemName: field.isComplete ? "checkmark.circle.fill" : "circle")
                        .foregroundColor(field.isComplete ? .green : .gray)
                        .frame(width: 20)
                    
                    VStack(alignment: .leading) {
                        Text(field.label)
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Text(field.value.isEmpty ? field.placeholder : field.value)
                            .font(.footnote)
                            .foregroundColor(field.value.isEmpty ? .gray : .primary)
                            .lineLimit(1)
                    }
                    
                    Spacer()
                    
                    if index == form.currentFieldIndex {
                        Image(systemName: "arrowtriangle.right.fill")
                            .foregroundColor(.blue)
                            .font(.caption)
                    }
                }
                .padding(.vertical, 8)
                .padding(.horizontal, 12)
                .background(index == form.currentFieldIndex ? Color.blue.opacity(0.1) : Color.clear)
                .cornerRadius(8)
                .onTapGesture {
                    if !isRecording {
                        form.moveToField(at: index)
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
    }
    
    private var completionToolbar: some View {
        HStack(spacing: 16) {
            Button(action: copyToClipboard) {
                Label("Copiar", systemImage: "doc.on.doc")
                    .font(.footnote)
            }
            .buttonStyle(.borderedProminent)
            
            Button(action: shareForm) {
                Label("Compartilhar", systemImage: "square.and.arrow.up")
                    .font(.footnote)
            }
            .buttonStyle(.bordered)
            
            Button(action: { form.reset() }) {
                Label("Limpar", systemImage: "trash")
                    .font(.footnote)
            }
            .buttonStyle(.bordered)
            .foregroundColor(.red)
        }
        .padding()
        .background(Color(.systemGray6))
    }
    
    private var controlToolbar: some View {
        HStack {
            Button(action: moveToPreviousField) {
                Image(systemName: "chevron.left")
                    .frame(width: 44, height: 44)
            }
            .disabled(form.currentFieldIndex == 0 || isRecording || isContinuousMode)
            
            Spacer()
            
            Button(action: toggleRecording) {
                VStack(spacing: 4) {
                    Image(systemName: isRecording ? "stop.fill" : "mic.fill")
                        .font(.title2)
                        .foregroundColor(isRecording ? .red : .white)
                    Text(isRecording ? "Parar" : "Gravar")
                        .font(.caption)
                        .foregroundColor(isRecording ? .red : .white)
                }
                .frame(width: 80, height: 80)
                .background(isRecording ? Color.red.opacity(0.2) : Color.red)
                .clipShape(Circle())
            }
            
            Spacer()
            
            Button(action: moveToNextField) {
                Image(systemName: "chevron.right")
                    .frame(width: 44, height: 44)
            }
            .disabled(form.currentFieldIndex == form.fields.count - 1 || isRecording || isContinuousMode)
        }
        .padding()
        .background(Color(.systemGray6))
    }
    
    private func setupRecorder() {
        let onFieldComplete: ((String) -> Void)? = isContinuousMode ? nil : { transcribedText in
            DispatchQueue.main.async {
                if !transcribedText.isEmpty {
                    form.updateCurrentFieldValue(transcribedText)
                }
            }
        }
        
        let onContinuousComplete: ((ExtractionResult) -> Void)? = isContinuousMode ? { result in
            DispatchQueue.main.async {
                extractionResult = result
                showingPreview = true
            }
        } : nil
        
        speechTranscriber = SpokenWordTranscriber(
            form: form,
            onFieldComplete: onFieldComplete,
            onContinuousComplete: onContinuousComplete,
            isContinuousMode: isContinuousMode
        )
        
        if let transcriber = speechTranscriber {
            recorder = Recorder(transcriber: transcriber, form: form)
        }
    }
    
    private func toggleRecording() {
        if isRecording {
            stopRecording()
        } else {
            startRecording()
        }
    }
    
    private func startRecording() {
        guard let recorder = recorder else { return }
        
        isRecording = true
        Task {
            do {
                try await recorder.record()
            } catch {
                print("Recording error: \(error)")
                isRecording = false
            }
        }
    }
    
    private func stopRecording() {
        guard let recorder = recorder else { return }
        
        Task {
            do {
                try await recorder.stopRecording()
                
                if isContinuousMode {
                    await speechTranscriber?.finishContinuousTranscription()
                }
                
                isRecording = false
                
                if !isContinuousMode && form.currentField?.isComplete == true && form.currentFieldIndex < form.fields.count - 1 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        _ = form.moveToNextField()
                    }
                }
            } catch {
                print("Stop recording error: \(error)")
                isRecording = false
            }
        }
    }
    
    private func moveToNextField() {
        _ = form.moveToNextField()
    }
    
    private func moveToPreviousField() {
        _ = form.moveToPreviousField()
    }
    
    private func copyToClipboard() {
        UIPasteboard.general.string = form.generateFilledTemplate()
        showCopiedAlert = true
    }
    
    private func shareForm() {
        let text = form.generateFilledTemplate()
        let activityVC = UIActivityViewController(activityItems: [text], applicationActivities: nil)
        
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first,
           let rootVC = window.rootViewController {
            rootVC.present(activityVC, animated: true)
        }
    }
    
    private func validationMessage(for field: TemplateField) -> String {
        switch field.fieldType {
        case .number:
            return "Digite apenas números"
        case .date:
            return "Use o formato DD/MM/AAAA"
        case .time:
            return "Use o formato HH:MM"
        case .phone:
            return "Digite um telefone válido (10 ou 11 dígitos)"
        default:
            return "Campo inválido"
        }
    }
}