import SwiftUI
import FoundationModels

struct FormPreviewView: View {
    @State private var extractionResult: ExtractionResult
    @State private var form: SurgicalRequestForm
    @State private var isRefining = false
    @State private var showingAlternatives: String? = nil
    
    let onConfirm: (SurgicalRequestForm) -> Void
    let onRetry: () -> Void
    
    init(extractionResult: ExtractionResult, form: SurgicalRequestForm, onConfirm: @escaping (SurgicalRequestForm) -> Void, onRetry: @escaping () -> Void) {
        self._extractionResult = State(initialValue: extractionResult)
        self._form = State(initialValue: form)
        self.onConfirm = onConfirm
        self.onRetry = onRetry
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                overallConfidenceHeader
                
                ScrollView {
                    VStack(spacing: 16) {
                        extractedEntitiesSection
                        unprocessedTextSection
                        originalTranscriptionSection
                    }
                    .padding()
                }
                
                actionButtons
            }
            .navigationTitle("Pré-visualização")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: Binding(
                get: { showingAlternatives != nil },
                set: { if !$0 { showingAlternatives = nil } }
            )) {
                if let fieldId = showingAlternatives {
                    AlternativesSheet(
                        fieldId: fieldId,
                        form: form,
                        extractionResult: extractionResult,
                        onUpdate: updateFieldValue
                    )
                }
            }
        }
    }
    
    private var overallConfidenceHeader: some View {
        VStack(spacing: 8) {
            HStack {
                Image(systemName: confidenceIcon(extractionResult.confidence))
                    .foregroundColor(confidenceColor(extractionResult.confidence))
                
                Text("Confiança Geral: \(Int(extractionResult.confidence * 100))%")
                    .font(.headline)
                    .foregroundColor(confidenceColor(extractionResult.confidence))
                
                Spacer()
            }
            
            ProgressView(value: extractionResult.confidence)
                .tint(confidenceColor(extractionResult.confidence))
        }
        .padding()
        .background(confidenceColor(extractionResult.confidence).opacity(0.1))
    }
    
    private var extractedEntitiesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Informações Extraídas")
                .font(.headline)
                .padding(.bottom, 8)
            
            ForEach(form.fields, id: \.id) { field in
                EntityPreviewCard(
                    field: field,
                    extractedEntity: extractionResult.entities.first { $0.fieldId == field.id },
                    onEdit: { editField(field.id) },
                    onShowAlternatives: { showingAlternatives = field.id },
                    onRefine: { refineField(field.id) }
                )
            }
        }
    }
    
    private var unprocessedTextSection: some View {
        Group {
            if !extractionResult.unprocessedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Texto Não Processado")
                        .font(.headline)
                        .foregroundColor(.orange)
                    
                    Text(extractionResult.unprocessedText)
                        .font(.body)
                        .padding()
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.orange.opacity(0.3), lineWidth: 1)
                        )
                    
                    Text("Este texto pode conter informações importantes que não foram extraídas automaticamente.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
    }
    
    private var originalTranscriptionSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Transcrição Original")
                .font(.headline)
            
            Text(getOriginalTranscription())
                .font(.footnote)
                .foregroundColor(.secondary)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
        }
    }
    
    private var actionButtons: some View {
        HStack(spacing: 16) {
            Button(action: onRetry) {
                Label("Tentar Novamente", systemImage: "arrow.clockwise")
                    .font(.footnote)
            }
            .buttonStyle(.bordered)
            
            Button(action: { onConfirm(form) }) {
                Label("Confirmar", systemImage: "checkmark")
                    .font(.footnote)
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .background(Color(.systemGray6))
    }
    
    private func confidenceIcon(_ confidence: Double) -> String {
        switch confidence {
        case 0.9...1.0: return "checkmark.circle.fill"
        case 0.7..<0.9: return "exclamationmark.triangle.fill"
        default: return "xmark.circle.fill"
        }
    }
    
    private func confidenceColor(_ confidence: Double) -> Color {
        switch confidence {
        case 0.9...1.0: return .green
        case 0.7..<0.9: return .orange
        default: return .red
        }
    }
    
    private func editField(_ fieldId: String) {
        // Open inline editor for the field
        print("Edit field: \(fieldId)")
    }
    
    private func refineField(_ fieldId: String) {
        guard let entity = extractionResult.entities.first(where: { $0.fieldId == fieldId }) else { return }
        
        isRefining = true
        Task {
            do {
                let extractor = EntityExtractor.shared
                let refined = try await extractor.refineEntity(
                    fieldId: fieldId,
                    originalValue: entity.value,
                    context: entity.originalText
                )
                
                await MainActor.run {
                    if let refined = refined,
                       let fieldIndex = form.fields.firstIndex(where: { $0.id == fieldId }) {
                        form.fields[fieldIndex].value = refined.value
                        
                        // Update the extraction result
                        if let entityIndex = extractionResult.entities.firstIndex(where: { $0.fieldId == fieldId }) {
                            extractionResult.entities[entityIndex] = refined
                        }
                    }
                    isRefining = false
                }
            } catch {
                await MainActor.run {
                    isRefining = false
                }
            }
        }
    }
    
    private func updateFieldValue(_ fieldId: String, _ newValue: String) {
        if let fieldIndex = form.fields.firstIndex(where: { $0.id == fieldId }) {
            form.fields[fieldIndex].value = newValue
        }
    }
    
    private func getOriginalTranscription() -> String {
        return extractionResult.entities.first?.originalText ?? "Sem transcrição disponível"
    }
}

struct EntityPreviewCard: View {
    let field: TemplateField
    let extractedEntity: ExtractedEntity?
    let onEdit: () -> Void
    let onShowAlternatives: () -> Void
    let onRefine: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: field.isComplete ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(field.isComplete ? .green : .gray)
                
                Text(field.label)
                    .font(.headline)
                
                Spacer()
                
                if let entity = extractedEntity {
                    ConfidenceBadge(confidence: entity.confidence)
                }
            }
            
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Valor:")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Text(field.value.isEmpty ? field.placeholder : field.value)
                        .font(.body)
                        .foregroundColor(field.value.isEmpty ? .gray : .primary)
                }
                
                Spacer()
                
                VStack(spacing: 8) {
                    Button("Editar", action: onEdit)
                        .buttonStyle(.bordered)
                        .font(.caption)
                    
                    if let entity = extractedEntity, !entity.alternatives.isEmpty {
                        Button("Alternativas", action: onShowAlternatives)
                            .buttonStyle(.bordered)
                            .font(.caption)
                    }
                    
                    if extractedEntity != nil {
                        Button("Refinar", action: onRefine)
                            .buttonStyle(.bordered)
                            .font(.caption)
                    }
                }
            }
            
            if let field = field as? TemplateField, !field.value.isEmpty && !field.validate() {
                HStack {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundColor(.red)
                    Text("Valor inválido para este campo")
                        .font(.caption)
                        .foregroundColor(.red)
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
    }
}

struct ConfidenceBadge: View {
    let confidence: Double
    
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: iconName)
                .font(.caption)
            Text("\(Int(confidence * 100))%")
                .font(.caption)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(backgroundColor)
        .foregroundColor(textColor)
        .cornerRadius(12)
    }
    
    private var iconName: String {
        switch confidence {
        case 0.9...1.0: return "checkmark"
        case 0.7..<0.9: return "exclamationmark"
        default: return "xmark"
        }
    }
    
    private var backgroundColor: Color {
        switch confidence {
        case 0.9...1.0: return .green.opacity(0.2)
        case 0.7..<0.9: return .orange.opacity(0.2)
        default: return .red.opacity(0.2)
        }
    }
    
    private var textColor: Color {
        switch confidence {
        case 0.9...1.0: return .green
        case 0.7..<0.9: return .orange
        default: return .red
        }
    }
}

struct AlternativesSheet: View {
    let fieldId: String
    @State private var form: SurgicalRequestForm
    let extractionResult: ExtractionResult
    let onUpdate: (String, String) -> Void
    
    @Environment(\.dismiss) private var dismiss
    
    init(fieldId: String, form: SurgicalRequestForm, extractionResult: ExtractionResult, onUpdate: @escaping (String, String) -> Void) {
        self.fieldId = fieldId
        self._form = State(initialValue: form)
        self.extractionResult = extractionResult
        self.onUpdate = onUpdate
    }
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                if let field = form.fields.first(where: { $0.id == fieldId }),
                   let entity = extractionResult.entities.first(where: { $0.fieldId == fieldId }) {
                    
                    Text(field.label)
                        .font(.headline)
                    
                    Text("Valor Atual:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Button(action: {}) {
                        Text(entity.value)
                            .font(.body)
                            .foregroundColor(.primary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.blue, lineWidth: 2)
                            )
                    }
                    
                    if !entity.alternatives.isEmpty {
                        Text("Alternativas:")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .padding(.top)
                        
                        ForEach(entity.alternatives, id: \.self) { alternative in
                            Button(action: {
                                onUpdate(fieldId, alternative)
                                dismiss()
                            }) {
                                Text(alternative)
                                    .font(.body)
                                    .foregroundColor(.primary)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding()
                                    .background(Color(.systemGray6))
                                    .cornerRadius(8)
                            }
                        }
                    }
                    
                    Spacer()
                }
            }
            .padding()
            .navigationTitle("Alternativas")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancelar") {
                        dismiss()
                    }
                }
            }
        }
    }
}