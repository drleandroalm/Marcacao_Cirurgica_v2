/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The app's main view.
*/

import SwiftUI
import Speech

struct ContentView: View {
    var body: some View {
        FormFillerView()
    }
}
