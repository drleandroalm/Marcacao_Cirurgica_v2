import Foundation

enum FieldType {
    case text
    case number
    case date
    case time
    case phone
}

struct TemplateField: Identifiable {
    let id: String
    let label: String
    let placeholder: String
    var value: String
    let fieldType: FieldType
    let isRequired: Bool
    
    init(id: String, label: String, placeholder: String, value: String = "", fieldType: FieldType = .text, isRequired: Bool = true) {
        self.id = id
        self.label = label
        self.placeholder = placeholder
        self.value = value
        self.fieldType = fieldType
        self.isRequired = isRequired
    }
    
    var isComplete: Bool {
        return !value.isEmpty
    }
    
    func validate() -> Bool {
        guard isRequired && !value.isEmpty else {
            return !isRequired
        }
        
        switch fieldType {
        case .number:
            return Int(value) != nil
        case .date:
            let components = value.split(separator: "/")
            guard components.count == 3,
                  let day = Int(components[0]), day >= 1, day <= 31,
                  let month = Int(components[1]), month >= 1, month <= 12,
                  let year = Int(components[2]), year >= 2024, year <= 2100 else {
                return false
            }
            return true
        case .time:
            let components = value.split(separator: ":")
            guard components.count == 2,
                  let hour = Int(components[0]), hour >= 0, hour <= 23,
                  let minute = Int(components[1]), minute >= 0, minute <= 59 else {
                return false
            }
            return true
        case .phone:
            let cleaned = value.filter { $0.isNumber }
            return cleaned.count >= 10 && cleaned.count <= 11
        case .text:
            return !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
    }
    
    func formattedValue() -> String {
        switch fieldType {
        case .phone:
            let cleaned = value.filter { $0.isNumber }
            if cleaned.count == 11 {
                let formatted = "(\(cleaned.prefix(2))) \(cleaned.dropFirst(2).prefix(5))-\(cleaned.suffix(4))"
                return formatted
            } else if cleaned.count == 10 {
                let formatted = "(\(cleaned.prefix(2))) \(cleaned.dropFirst(2).prefix(4))-\(cleaned.suffix(4))"
                return formatted
            }
            return value
        default:
            return value
        }
    }
}